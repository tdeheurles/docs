Configuration FileResourceDemo
{
    Node "localhost"
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }
        
        File Download_Directory 
        {
            Ensure          = "Present"
            Type            = "Directory"
            Recurse         = $true
            DestinationPath = "C:\DeploymentDownloads"
        }
        
        Script Install_dotNet461
        {
            DependsOn  = "[File]Download_Directory"
            GetScript  = { @{ Result = "" } }
            TestScript = { $false }
            SetScript  = {
                $now = date
                Write-Verbose "${$now.Date} -- Install_dotNet461"
                $client = New-Object -TypeName System.Net.WebClient
                $url = "https://download.microsoft.com/download/E/4/1/E4173890-A24A-4936-9FC9-AF930FE3FA40/NDP461-KB3102436-x86-x64-AllOS-ENU.exe"
                $dest = "C:\DeploymentDownloads\net461.exe"
                $name = ".NET461"
                for ($i=1; $i -le 10; $i++) {
                    try { 
                        $client.DownloadFile($url, $dest)
                    }
                    catch { 
                        $now = date
                        if ($i -eq 9) {
                            Write-Error "${$now.Date} -- Error when downloading $name, exiting"
                            return
                        }
                        else {
                            Write-Warning "${$now.Date} -- Error when downloading $name, attempting in a moment ..." >> "C:\log.txt"
                        }
                        Start-Sleep $i * 2
                    }
                }
                
                $psi = new-object "Diagnostics.ProcessStartInfo"
                $psi.FileName = $dest 
                $psi.Arguments = " /q"
                $proc = [Diagnostics.Process]::Start($psi)
                $proc.WaitForExit()
            }
        }
        
        Script Install_VSCode
        {
            DependsOn  = "[File]Download_Directory"
            GetScript  = { @{ Result = "" } }
            TestScript = { $false }
            SetScript  = {
                Write-Verbose "Install_VSCode"
                $client = New-Object -TypeName System.Net.WebClient
                $url = "https://go.microsoft.com/fwlink/?LinkID=623230"
                $dest = "C:\DeploymentDownloads\VSCodeSetup-stable.exe"
                $name = "VSCode"
                for ($i=1; $i -le 10; $i++) {
                    try { 
                        $client.DownloadFile($url, $dest)
                    }
                    catch { 
                        $now = date
                        if ($i -eq 9) {
                            Write-Error "${$now.Date} -- Error when downloading $name, exiting"
                            return
                        }
                        else {
                            Write-Warning "${$now.Date} -- Error when downloading $name, attempting in a moment ..." >> "C:\log.txt"
                        }
                        Start-Sleep $i * 2
                    }
                }
                
                $psi = new-object "Diagnostics.ProcessStartInfo"
                $psi.FileName = $dest 
                $psi.Arguments = " /SILENT"
                $proc = [Diagnostics.Process]::Start($psi)
                $proc.WaitForExit()
            }
        } 
 
        Script Install_LinqPad
        {
            DependsOn = "[Script]Install_dotNet461"
            GetScript  = { @{ Result = "" } }
            TestScript = { $false }
            SetScript  = {
                Write-Verbose "Install_LinqPad"
                $client = New-Object -TypeName System.Net.WebClient
                $url = "http://www.linqpad.net/GetFile.aspx?LINQPad5Setup.exe"
                $dest = "C:\DeploymentDownloads\LINQPad5Setup.exe"
                $name = "Linqpad"
                for ($i=1; $i -le 10; $i++) {
                    try { 
                        $client.DownloadFile($url, $dest)
                    }
                    catch { 
                        $now = date
                        if ($i -eq 9) {
                            Write-Error "${$now.Date} -- Error when downloading $name, exiting"
                            return
                        }
                        else {
                            Write-Warning "${$now.Date} -- Error when downloading $name, attempting in a moment ..." >> "C:\log.txt"
                        }
                        Start-Sleep $i * 2
                    }
                }
                                
                $psi = new-object "Diagnostics.ProcessStartInfo"
                $psi.FileName = $dest 
                $psi.Arguments = " /silent /mergetasks='lprunpath'"
                $proc = [Diagnostics.Process]::Start($psi)
                $proc.WaitForExit()
            }
        } 
 
        # Script Install_Eventstore
        # {
        #     DependsOn = "[Script]Install_LinqPad"
        #     GetScript  = { @{ Result = "" } }
        #     TestScript = { $false }
        #     SetScript  = {
        #         Write-Verbose "Install Eventstore as a service"
        #         & "C:\Program Files (x86)\LINQPad5\LPRun.exe" "$thisScriptPath\1Node-Eventstore-Install.linq" > $eventstoreInstallLog 
        #     }
        # }
    }
}