Configuration FileResourceDemo
{
    Node "localhost"
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }

        Script Install_dotNet461
        {
            GetScript  = { @{ Result = "" } }
            TestScript = { $false }
            SetScript  = {
                $client = New-Object -TypeName System.Net.WebClient
                $url = "https://download.microsoft.com/download/E/4/1/E4173890-A24A-4936-9FC9-AF930FE3FA40/NDP461-KB3102436-x86-x64-AllOS-ENU.exe"
                $dest = $env:TEMP + "\net461.exe"
                for ($i=1; $i -le 10; $i++) {
                    try { 
                        $client.DownloadFile($url, $dest)
                        return
                    }
                    catch { 
                        Start-Sleep $i * 2
                    }
                }
                
                $psi = new-object "Diagnostics.ProcessStartInfo"
                $psi.FileName = $dest 
                $psi.Arguments = " /q"
                $proc = [Diagnostics.Process]::Start($psi)
                $proc.WaitForExit()
            }
        }
        
        Script Install_VSCode
        {
            GetScript  = { @{ Result = "" } }
            TestScript = { $false }
            SetScript  = {
                $client = New-Object -TypeName System.Net.WebClient
                $url = "https://go.microsoft.com/fwlink/?LinkID=623230"
                $dest = $env:TEMP + "\VSCodeSetup-stable.exe"
                for ($i=1; $i -le 10; $i++) {
                    try { 
                        $client.DownloadFile($url, $dest)
                        return
                    }
                    catch { 
                        Start-Sleep $i * 2
                    }
                }
                
                $psi = new-object "Diagnostics.ProcessStartInfo"
                $psi.FileName = $dest 
                $psi.Arguments = " /SILENT"
                $proc = [Diagnostics.Process]::Start($psi)
                $proc.WaitForExit()
            }
        } 
 
        Script Install_LinqPad
        {
            DependsOn = "[Script]Install_dotNet461"
            GetScript  = { @{ Result = "" } }
            TestScript = { $false }
            SetScript  = {
                $client = New-Object -TypeName System.Net.WebClient
                $dest = $env:TEMP + "\LINQPad5Setup.exe"
                $url = "http://www.linqpad.net/GetFile.aspx?LINQPad5Setup.exe"
                for ($i=1; $i -le 10; $i++) {
                    try { 
                        $client.DownloadFile($url, $dest)
                        return
                    }
                    catch { 
                        Start-Sleep $i * 2
                    }
                }
                
                $psi = new-object "Diagnostics.ProcessStartInfo"
                $psi.FileName = $dest 
                $psi.Arguments = " /silent /mergetasks='lprunpath'"
                $proc = [Diagnostics.Process]::Start($psi)
                $proc.WaitForExit()
            }
        } 
 
        # Script Install_Eventstore
        # {
        #     DependsOn = "[Script]Install_LinqPad"
        #     GetScript  = { @{ Result = "" } }
        #     TestScript = { $false }
        #     SetScript  = {
        #         & "C:\Program Files (x86)\LINQPad5\LPRun.exe" "$thisScriptPath\1Node-Eventstore-Install.linq" > $eventstoreInstallLog 
        #     }
        # }  
    }
}